:HL["/_next/static/chunks/3x8rb4x4s1b0l.css","style"]
:HL["https://fonts.googleapis.com/css2?family=DM+Sans:ital,opsz,wght@0,9..40,400;0,9..40,500;0,9..40,600;0,9..40,700;1,9..40,400&family=IBM+Plex+Mono:wght@400;500&display=swap","style"]
2:[["children",{"s":"__PAGE__","h":160}]]
1:[["children",{"s":"bi-avancado","h":96,"c":"$Q2"}]]
0:{"b":"-sXJ5PSQRBg8VqWv7qXWh","t":{"t":{"s":"","h":84,"c":"$Q1"}}}
