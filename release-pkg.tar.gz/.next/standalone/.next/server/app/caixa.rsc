1:"/_next/static/chunks/2lit97gt7repc.js"
2:"/_next/static/chunks/3kjwf8l6firsj.js"
3:"/_next/static/chunks/1g1uskodj_ztb.js"
4:"LoadingBoundaryProvider"
5:I[39756,["$1","$2","$3"],"$4"]
6:"$Sreact.fragment"
7:I[44636,["$1","$2","$3"],"Providers"]
8:I[27977,["$1","$2","$3"],"ClientLayout"]
9:I[39756,["$1","$2","$3"],"default"]
a:"/_next/static/chunks/3gvfh6urb76vc.js"
b:I[58298,["$1","$2","$3","$a"],"default"]
c:I[37457,["$1","$2","$3"],"default"]
10:I[47257,["$1","$2","$3"],"ClientPageRoot"]
11:"/_next/static/chunks/3u-7m_bd6_ngi.js"
12:I[85261,["$1","$2","$3","$11"],"default"]
15:I[97367,["$1","$2","$3"],"OutletBoundary"]
16:"$Sreact.suspense"
18:"ViewportBoundary"
19:I[97367,["$1","$2","$3"],"$18"]
1b:"MetadataBoundary"
1c:I[97367,["$1","$2","$3"],"$1b"]
1e:I[68027,["$1","$2","$3"],"default",1]
:HL["/_next/static/chunks/3x8rb4x4s1b0l.css","style"]
:HL["https://fonts.googleapis.com/css2?family=DM+Sans:ital,opsz,wght@0,9..40,400;0,9..40,500;0,9..40,600;0,9..40,700;1,9..40,400&family=IBM+Plex+Mono:wght@400;500&display=swap","style"]
e:X
f:[["children",{"s":"__PAGE__","h":512,"d":{"r":["$","$6","c",{"children":[["$","$L10",null,{"Component":"$12","serverProvidedParams":{"searchParams":{},"params":{},"promises":["$@13","$@14"]}}],[["$","script","script-0",{"src":"/_next/static/chunks/3u-7m_bd6_ngi.js","async":true,"nonce":"$undefined"}]],["$","$L15",null,{"children":["$","$16",null,{"name":"Next.MetadataOutlet","children":"$@17"}]}]]}],"p":false,"v":null}}]]
d:[["children",{"s":"caixa","h":512,"d":{"r":["$","$6","c",{"children":[null,["$","$L9",null,{"parallelRouterKey":"children","error":"$undefined","errorStyles":"$undefined","errorScripts":"$undefined","template":["$","$Lc",null,{}],"templateStyles":"$undefined","templateScripts":"$undefined","notFound":"$undefined","forbidden":"$undefined","unauthorized":"$undefined"}]]}],"p":false,"v":"$e"},"c":"$Qf"}]]
0:{"P":null,"c":["","caixa"],"q":"","i":false,"t":{"t":{"s":"","h":532,"d":{"r":["$","$L5",null,{"loading":[["$","div","l",{"className":"flex items-center justify-center py-20","children":["$","p",null,{"className":"animate-pulse text-sm text-[var(--muted)]","children":"Carregando..."}]}],[],null],"children":["$","$6","c",{"children":[[["$","link","0",{"rel":"stylesheet","href":"/_next/static/chunks/3x8rb4x4s1b0l.css","precedence":"next","crossOrigin":"$undefined","nonce":"$undefined"}],["$","script","script-0",{"src":"/_next/static/chunks/2lit97gt7repc.js","async":true,"nonce":"$undefined"}],["$","script","script-1",{"src":"/_next/static/chunks/3kjwf8l6firsj.js","async":true,"nonce":"$undefined"}],["$","script","script-2",{"src":"/_next/static/chunks/1g1uskodj_ztb.js","async":true,"nonce":"$undefined"}]],["$","html",null,{"lang":"pt-BR","children":[["$","head",null,{"children":[["$","link",null,{"rel":"icon","type":"image/svg+xml","href":"/favicon.svg"}],["$","link",null,{"rel":"preconnect","href":"https://fonts.googleapis.com"}],["$","link",null,{"rel":"preconnect","href":"https://fonts.gstatic.com","crossOrigin":"anonymous"}],["$","link",null,{"href":"https://fonts.googleapis.com/css2?family=DM+Sans:ital,opsz,wght@0,9..40,400;0,9..40,500;0,9..40,600;0,9..40,700;1,9..40,400&family=IBM+Plex+Mono:wght@400;500&display=swap","rel":"stylesheet"}]]}],["$","body",null,{"children":["$","$L7",null,{"children":["$","$L8",null,{"children":["$","$L9",null,{"parallelRouterKey":"children","error":"$b","errorStyles":[],"errorScripts":[["$","script","script-0",{"src":"/_next/static/chunks/3gvfh6urb76vc.js","async":true,"nonce":"$undefined"}]],"template":["$","$Lc",null,{}],"templateStyles":"$undefined","templateScripts":"$undefined","notFound":[[["$","title",null,{"children":"404: This page could not be found."}],["$","div",null,{"style":{"fontFamily":"system-ui,\"Segoe UI\",Roboto,Helvetica,Arial,sans-serif,\"Apple Color Emoji\",\"Segoe UI Emoji\"","height":"100vh","textAlign":"center","display":"flex","flexDirection":"column","alignItems":"center","justifyContent":"center"},"children":["$","div",null,{"children":[["$","style",null,{"dangerouslySetInnerHTML":{"__html":"body{color:#000;background:#fff;margin:0}.next-error-h1{border-right:1px solid rgba(0,0,0,.3)}@media (prefers-color-scheme:dark){body{color:#fff;background:#000}.next-error-h1{border-right:1px solid rgba(255,255,255,.3)}}"}}],["$","h1",null,{"className":"next-error-h1","style":{"display":"inline-block","margin":"0 20px 0 0","padding":"0 23px 0 0","fontSize":24,"fontWeight":500,"verticalAlign":"top","lineHeight":"49px"},"children":404}],["$","div",null,{"style":{"display":"inline-block"},"children":["$","h2",null,{"style":{"fontSize":14,"fontWeight":400,"lineHeight":"49px","margin":0},"children":"This page could not be found."}]}]]}]}]],[]],"forbidden":"$undefined","unauthorized":"$undefined"}]}]}]}]]}]]}]}],"p":false,"v":null},"c":"$Qd"},"h":{"r":["$","$6","h",{"children":[null,["$","$L19",null,{"children":"$L1a"}],["$","$L1c",null,{"children":[["$","div",null,{"hidden":true,"children":["$","$16",null,{"name":"Next.Metadata","children":"$L1d"}]}],null]}],null]}],"p":false,"v":null}},"m":"$undefined","G":["$1e",[["$","link","0",{"rel":"stylesheet","href":"/_next/static/chunks/3x8rb4x4s1b0l.css","precedence":"next","crossOrigin":"$undefined","nonce":"$undefined"}]]],"S":true,"r":"$undefined","s":"$undefined","a":"$undefined","l":"$undefined","p":"$undefined","d":"$undefined","b":"-sXJ5PSQRBg8VqWv7qXWh"}
e:C
13:{}
14:"$f:0:1:d:r:props:children:0:props:serverProvidedParams:params"
1a:[["$","meta","0",{"charSet":"utf-8"}],["$","meta","1",{"name":"viewport","content":"width=device-width, initial-scale=1"}]]
17:null
1d:[["$","title","0",{"children":"IAlicita — Portal de Licitações"}],["$","meta","1",{"name":"description","content":"Busca, classificação e monitoramento de licitações públicas brasileiras com IA."}]]
