var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/cnpj/route.js")
R.c("server/chunks/[externals]__12s2uxrv8n30f._.js")
R.c("server/chunks/[root-of-the-server]__1v1-l-83czzsr._.js")
R.c("server/chunks/_1zpvpqjuy3cmg._.js")
R.c("server/chunks/_next-internal_server_app_api_cnpj_route_actions_0rb6tb4bpad71.js")
R.m(90534)
module.exports=R.m(90534).exports
