var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/check-url/route.js")
R.c("server/chunks/[externals]__12s2uxrv8n30f._.js")
R.c("server/chunks/[root-of-the-server]__1v1-l-83czzsr._.js")
R.c("server/chunks/_1m5zf28-mzemh._.js")
R.c("server/chunks/_next-internal_server_app_api_check-url_route_actions_158lk1jrfpkjh.js")
R.m(9907)
module.exports=R.m(9907).exports
