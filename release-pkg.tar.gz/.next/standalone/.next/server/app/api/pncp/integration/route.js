var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/pncp/integration/route.js")
R.c("server/chunks/[externals]__12s2uxrv8n30f._.js")
R.c("server/chunks/[root-of-the-server]__1v1-l-83czzsr._.js")
R.c("server/chunks/_1a8trzf7gwyv9._.js")
R.c("server/chunks/_next-internal_server_app_api_pncp_integration_route_actions_190rik36hvj9d.js")
R.m(56357)
module.exports=R.m(56357).exports
