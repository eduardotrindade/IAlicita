var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/pncp/route.js")
R.c("server/chunks/[externals]__12s2uxrv8n30f._.js")
R.c("server/chunks/src_lib_pncpMockData_ts_0wt0pa6co31sq._.js")
R.c("server/chunks/_2189-whi6jq79._.js")
R.c("server/chunks/[root-of-the-server]__1v1-l-83czzsr._.js")
R.c("server/chunks/_next-internal_server_app_api_pncp_route_actions_0e9cj60-nkz69.js")
R.m(79353)
module.exports=R.m(79353).exports
