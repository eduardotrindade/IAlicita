var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/compras-gov/route.js")
R.c("server/chunks/[externals]__12s2uxrv8n30f._.js")
R.c("server/chunks/[root-of-the-server]__1v1-l-83czzsr._.js")
R.c("server/chunks/_1yb78c4vhx-7r._.js")
R.c("server/chunks/_next-internal_server_app_api_compras-gov_route_actions_0jr9b_o_azcnf.js")
R.m(13939)
module.exports=R.m(13939).exports
