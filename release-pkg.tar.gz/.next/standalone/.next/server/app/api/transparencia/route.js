var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/transparencia/route.js")
R.c("server/chunks/[externals]__12s2uxrv8n30f._.js")
R.c("server/chunks/[root-of-the-server]__1v1-l-83czzsr._.js")
R.c("server/chunks/_1phlyw3o1q_y_._.js")
R.c("server/chunks/_next-internal_server_app_api_transparencia_route_actions_1qqzgs5gikvws.js")
R.m(81600)
module.exports=R.m(81600).exports
