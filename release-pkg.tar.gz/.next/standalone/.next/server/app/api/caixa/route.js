var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/caixa/route.js")
R.c("server/chunks/[externals]__12s2uxrv8n30f._.js")
R.c("server/chunks/src_lib_pncpMockData_ts_0wt0pa6co31sq._.js")
R.c("server/chunks/_12cokp9tt3qbk._.js")
R.c("server/chunks/[root-of-the-server]__1v1-l-83czzsr._.js")
R.c("server/chunks/_next-internal_server_app_api_caixa_route_actions_208q784lzoo3q.js")
R.m(49489)
module.exports=R.m(49489).exports
