globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/0cz1d0mv5g_q7.js"
  ],
  "lowPriorityFiles": [
    "static/-sXJ5PSQRBg8VqWv7qXWh/_buildManifest.js",
    "static/-sXJ5PSQRBg8VqWv7qXWh/_ssgManifest.js",
    "static/-sXJ5PSQRBg8VqWv7qXWh/_clientMiddlewareManifest.js"
  ],
  "rootMainFiles": [
    "static/chunks/2evgu094glu3w.js",
    "static/chunks/1kqj96yytewne.js",
    "static/chunks/3wbm-994r45kr.js",
    "static/chunks/turbopack-3-ry682tkyiqk.js"
  ],
  "rootMainFilesTree": {},
  "pagesChunkGroupBootstrapParams": {
    "/page": {
      "otherChunks": [
        "static/chunks/2evgu094glu3w.js",
        "static/chunks/1kqj96yytewne.js",
        "static/chunks/3wbm-994r45kr.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/_not-found/page": {
      "otherChunks": [
        "static/chunks/2evgu094glu3w.js",
        "static/chunks/1kqj96yytewne.js",
        "static/chunks/3wbm-994r45kr.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/_global-error/page": {
      "otherChunks": [
        "static/chunks/2evgu094glu3w.js",
        "static/chunks/1kqj96yytewne.js",
        "static/chunks/3wbm-994r45kr.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/alertas/page": {
      "otherChunks": [
        "static/chunks/2evgu094glu3w.js",
        "static/chunks/1kqj96yytewne.js",
        "static/chunks/3wbm-994r45kr.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/analisador-atestados/page": {
      "otherChunks": [
        "static/chunks/2evgu094glu3w.js",
        "static/chunks/1kqj96yytewne.js",
        "static/chunks/3wbm-994r45kr.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/analisador-especificacoes/page": {
      "otherChunks": [
        "static/chunks/2evgu094glu3w.js",
        "static/chunks/1kqj96yytewne.js",
        "static/chunks/3wbm-994r45kr.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/assistente-juridico/page": {
      "otherChunks": [
        "static/chunks/2evgu094glu3w.js",
        "static/chunks/1kqj96yytewne.js",
        "static/chunks/3wbm-994r45kr.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/bi-avancado/page": {
      "otherChunks": [
        "static/chunks/2evgu094glu3w.js",
        "static/chunks/1kqj96yytewne.js",
        "static/chunks/3wbm-994r45kr.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/buscas/page": {
      "otherChunks": [
        "static/chunks/2evgu094glu3w.js",
        "static/chunks/1kqj96yytewne.js",
        "static/chunks/3wbm-994r45kr.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/caixa/page": {
      "otherChunks": [
        "static/chunks/2evgu094glu3w.js",
        "static/chunks/1kqj96yytewne.js",
        "static/chunks/3wbm-994r45kr.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/certidoes-negativas/page": {
      "otherChunks": [
        "static/chunks/2evgu094glu3w.js",
        "static/chunks/1kqj96yytewne.js",
        "static/chunks/3wbm-994r45kr.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/classificacao-ia/page": {
      "otherChunks": [
        "static/chunks/2evgu094glu3w.js",
        "static/chunks/1kqj96yytewne.js",
        "static/chunks/3wbm-994r45kr.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/compliance/page": {
      "otherChunks": [
        "static/chunks/2evgu094glu3w.js",
        "static/chunks/1kqj96yytewne.js",
        "static/chunks/3wbm-994r45kr.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/dod/page": {
      "otherChunks": [
        "static/chunks/2evgu094glu3w.js",
        "static/chunks/1kqj96yytewne.js",
        "static/chunks/3wbm-994r45kr.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/empresas/page": {
      "otherChunks": [
        "static/chunks/2evgu094glu3w.js",
        "static/chunks/1kqj96yytewne.js",
        "static/chunks/3wbm-994r45kr.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/etp/page": {
      "otherChunks": [
        "static/chunks/2evgu094glu3w.js",
        "static/chunks/1kqj96yytewne.js",
        "static/chunks/3wbm-994r45kr.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/gestao-contratos/page": {
      "otherChunks": [
        "static/chunks/2evgu094glu3w.js",
        "static/chunks/1kqj96yytewne.js",
        "static/chunks/3wbm-994r45kr.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/grafo-societario/page": {
      "otherChunks": [
        "static/chunks/2evgu094glu3w.js",
        "static/chunks/1kqj96yytewne.js",
        "static/chunks/3wbm-994r45kr.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/mapa-competitividade/page": {
      "otherChunks": [
        "static/chunks/2evgu094glu3w.js",
        "static/chunks/1kqj96yytewne.js",
        "static/chunks/3wbm-994r45kr.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/mapas-uf/page": {
      "otherChunks": [
        "static/chunks/2evgu094glu3w.js",
        "static/chunks/1kqj96yytewne.js",
        "static/chunks/3wbm-994r45kr.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/matchmaking/page": {
      "otherChunks": [
        "static/chunks/2evgu094glu3w.js",
        "static/chunks/1kqj96yytewne.js",
        "static/chunks/3wbm-994r45kr.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/monitor-pca/page": {
      "otherChunks": [
        "static/chunks/2evgu094glu3w.js",
        "static/chunks/1kqj96yytewne.js",
        "static/chunks/3wbm-994r45kr.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/pesquisa-precos/page": {
      "otherChunks": [
        "static/chunks/2evgu094glu3w.js",
        "static/chunks/1kqj96yytewne.js",
        "static/chunks/3wbm-994r45kr.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/pipeline/page": {
      "otherChunks": [
        "static/chunks/2evgu094glu3w.js",
        "static/chunks/1kqj96yytewne.js",
        "static/chunks/3wbm-994r45kr.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/pncp-integracao/page": {
      "otherChunks": [
        "static/chunks/2evgu094glu3w.js",
        "static/chunks/1kqj96yytewne.js",
        "static/chunks/3wbm-994r45kr.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/portais/page": {
      "otherChunks": [
        "static/chunks/2evgu094glu3w.js",
        "static/chunks/1kqj96yytewne.js",
        "static/chunks/3wbm-994r45kr.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/propostas/page": {
      "otherChunks": [
        "static/chunks/2evgu094glu3w.js",
        "static/chunks/1kqj96yytewne.js",
        "static/chunks/3wbm-994r45kr.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/robo-lances/page": {
      "otherChunks": [
        "static/chunks/2evgu094glu3w.js",
        "static/chunks/1kqj96yytewne.js",
        "static/chunks/3wbm-994r45kr.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/sala-operacoes/page": {
      "otherChunks": [
        "static/chunks/2evgu094glu3w.js",
        "static/chunks/1kqj96yytewne.js",
        "static/chunks/3wbm-994r45kr.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/tr/page": {
      "otherChunks": [
        "static/chunks/2evgu094glu3w.js",
        "static/chunks/1kqj96yytewne.js",
        "static/chunks/3wbm-994r45kr.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    }
  },
  "chunkLoadingGlobal": "TURBOPACK"
};
