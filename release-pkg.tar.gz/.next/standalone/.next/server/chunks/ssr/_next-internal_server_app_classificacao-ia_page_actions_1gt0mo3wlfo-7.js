module.exports=[95759,a=>{"use strict";a.s([])}];

//# sourceMappingURL=_next-internal_server_app_classificacao-ia_page_actions_1gt0mo3wlfo-7.js.map