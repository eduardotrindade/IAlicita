module.exports=[90075,a=>{"use strict";a.s(["_",0,function(a){return new Intl.NumberFormat("pt-BR",{style:"currency",currency:"BRL",maximumFractionDigits:0}).format(a)},"w",0,function(a){return new Date(a).toLocaleDateString("pt-BR",{day:"2-digit",month:"short",year:"numeric"})},"Z",0,function(a){return`${Math.round(a)}%`}])}];

//# sourceMappingURL=src_lib_format_ts_1vrlyumfmy_4d._.js.map