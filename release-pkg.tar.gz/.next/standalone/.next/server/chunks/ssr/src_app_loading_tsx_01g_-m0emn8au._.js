module.exports=[2747,a=>{"use strict";var b=a.i(7997);a.s(["default",0,function(){return(0,b.jsx)("div",{className:"flex items-center justify-center py-20",children:(0,b.jsx)("p",{className:"animate-pulse text-sm text-[var(--muted)]",children:"Carregando..."})})}])},25210,function(a){a.n(a.i(2747))}];

//# sourceMappingURL=src_app_loading_tsx_01g_-m0emn8au._.js.map