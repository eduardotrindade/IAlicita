module.exports=[18455,a=>{"use strict";a.s([])}];

//# sourceMappingURL=_next-internal_server_app_mapa-competitividade_page_actions_0nm7qwjyhnw8n.js.map