module.exports=[23358,a=>{"use strict";a.s([])}];

//# sourceMappingURL=_next-internal_server_app_bi-avancado_page_actions_16tdohykejem2.js.map