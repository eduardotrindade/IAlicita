module.exports=[15058,a=>{"use strict";a.s([])}];

//# sourceMappingURL=_next-internal_server_app_empresas_page_actions_11j1rfpz5k4k9.js.map