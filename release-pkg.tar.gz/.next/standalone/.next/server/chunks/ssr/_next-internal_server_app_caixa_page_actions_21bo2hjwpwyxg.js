module.exports=[436,a=>{"use strict";a.s([])}];

//# sourceMappingURL=_next-internal_server_app_caixa_page_actions_21bo2hjwpwyxg.js.map