module.exports=[82096,a=>{"use strict";a.s([])}];

//# sourceMappingURL=_next-internal_server_app_propostas_page_actions_0tpdakeucyfbx.js.map