module.exports=[48399,a=>{"use strict";a.s([])}];

//# sourceMappingURL=_next-internal_server_app_buscas_page_actions_1hwsecyul69g8.js.map