module.exports=[34907,a=>{"use strict";a.s([])}];

//# sourceMappingURL=_next-internal_server_app_assistente-juridico_page_actions_1llyv7o-46r_j.js.map