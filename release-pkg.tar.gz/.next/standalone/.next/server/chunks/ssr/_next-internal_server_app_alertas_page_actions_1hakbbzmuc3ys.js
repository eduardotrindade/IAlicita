module.exports=[34775,a=>{"use strict";a.s([])}];

//# sourceMappingURL=_next-internal_server_app_alertas_page_actions_1hakbbzmuc3ys.js.map