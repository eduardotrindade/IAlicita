module.exports=[9037,a=>{"use strict";a.s([])}];

//# sourceMappingURL=_next-internal_server_app_grafo-societario_page_actions_0y_fe8zdzvgm2.js.map