module.exports=[36176,a=>{"use strict";a.s([])}];

//# sourceMappingURL=_next-internal_server_app_sala-operacoes_page_actions_1non11-gtr1mf.js.map