module.exports=[30443,s=>{"use strict";s.s([])}];

//# sourceMappingURL=_next-internal_server_app_api_compras-gov_route_actions_0jr9b_o_azcnf.js.map