module.exports=[27170,s=>{"use strict";s.s([])}];

//# sourceMappingURL=_next-internal_server_app_api_cnpj_route_actions_0rb6tb4bpad71.js.map