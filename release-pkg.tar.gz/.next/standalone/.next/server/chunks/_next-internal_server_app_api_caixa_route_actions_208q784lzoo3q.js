module.exports=[47630,s=>{"use strict";s.s([])}];

//# sourceMappingURL=_next-internal_server_app_api_caixa_route_actions_208q784lzoo3q.js.map