module.exports=[37452,s=>{"use strict";s.s([])}];

//# sourceMappingURL=_next-internal_server_app_api_transparencia_route_actions_1qqzgs5gikvws.js.map